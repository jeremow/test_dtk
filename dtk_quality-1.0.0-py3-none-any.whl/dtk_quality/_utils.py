from typing import Iterator
import datetime



def date_range(start_time: datetime.datetime, end_time: datetime.datetime) -> Iterator[datetime.date]:
    """
    :raise ValueError:
    """
    if not start_time < end_time:
        raise ValueError("The start time must be earlier than the end time.")
    first_day: datetime.date = start_time.date()
    last_day: datetime.date = end_time.date()
    if end_time.time() == datetime.time(0, 0):
        last_day -= datetime.timedelta(days=1)
    current_date: datetime.date = first_day
    while current_date <= last_day:
        yield current_date
        current_date += datetime.timedelta(days=1)
