"""
This Python module aims to read measures and spectrums (*NetCDF4* data files)
generatred by the *quality-computer*.
"""
from ._measure import MeasureData, MeasureType
from ._spectrum import SpectrumData
from ._io import read_measures, read_spectrums
