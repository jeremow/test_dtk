from typing import List
import dataclasses
import datetime

import numpy as np

import parsec

from ._others import UNIT_PARSER, TIME_PARSER, FLOAT_NUMBER_PARSER
from ._header import ParsedHeader, header_parser


@dataclasses.dataclass
class ParsedHourlySpectrums:
    """
    Represents a hourly measures parsed from a XML inner text.
    """
    #: Start time  parsed from the XML inner text
    start_time: datetime.time
    #: End time  parsed from the XML inner text
    end_time: datetime.time
    #: Unit parsed from the XML inner text
    unit: str
    #: Scale of the frequencies axis (0 = 'linear', 1 = 'logarithmic')
    scale: int
    #: Frequencies of the spectral values
    frequencies: List[float]
    #: Spectral values
    values: List[float]

    def __eq__(self, other: object) -> bool:
        def _nan_array_equal(a, b):
            """
            .. seealso:: https://stackoverflow.com/questions/10710328/comparing-numpy-arrays-containing-nan
            """
            try:
                np.testing.assert_array_equal(a, b)
            except AssertionError:
                return False
            return True

        if not isinstance(other, self.__class__):
            return False
        return self.start_time == other.start_time \
            and self.end_time == other.end_time \
            and self.unit == other.unit \
            and self.scale == other.scale \
            and self.frequencies == other.frequencies \
            and _nan_array_equal(self.values, other.values)


@dataclasses.dataclass
class ParsedStationSpectrums:
    """
    Represents a station measures parsed from a XML inner text.
    """
    #: Header parsed from the XML inner text
    header: ParsedHeader
    #: List of hourly measures parsed from the XML inner text
    hourly_spectrums: List[ParsedHourlySpectrums]


@parsec.generate
def hourly_spectrums_parser() -> ParsedHourlySpectrums:
    """
    :raise parsec.ParseError:
    :raise ValueError:
    """
    start_time_str: str = yield TIME_PARSER
    start_time: datetime.time = datetime.datetime.strptime(start_time_str, "%H%M").time()
    yield parsec.space()
    end_time_str: str = yield TIME_PARSER
    end_time: datetime.time = datetime.datetime.strptime(end_time_str, "%H%M").time()
    yield parsec.space()
    unit: str = yield UNIT_PARSER
    yield parsec.space()
    scale_str: str = yield parsec.one_of('01')
    scale: int = int(scale_str)
    yield parsec.space()

    spectral_frequencies_parser: parsec.Parser = parsec.many1(parsec.space() >> FLOAT_NUMBER_PARSER)
    spectral_frequencies_str: List[str] = yield spectral_frequencies_parser
    spectral_frequencies: List[float] = list(map(float, spectral_frequencies_str))

    yield parsec.space()

    spectral_values_parser: parsec.Parser = \
        parsec.many1(parsec.space() >> FLOAT_NUMBER_PARSER) << parsec.space() << parsec.string("nan")  # NOQA
    spectral_values_str: List[str] = yield spectral_values_parser
    spectral_values: List[float] = list(map(float, spectral_values_str))
    spectral_values.append(float('nan'))
    if len(spectral_frequencies) != len(spectral_values):
        raise ValueError("The number of frequancies and the number of spectral values must be the same.")
    return ParsedHourlySpectrums(
        start_time=start_time,
        end_time=end_time,
        unit=unit,
        scale=scale,
        frequencies=spectral_frequencies,
        values=spectral_values,
    )


@parsec.generate
def station_spectrums_parser() -> ParsedStationSpectrums:
    header: ParsedHeader = yield header_parser
    yield parsec.space()
    hourly_spectrums: List[ParsedHourlySpectrums] = \
        yield parsec.many1(parsec.space() >> hourly_spectrums_parser)

    return ParsedStationSpectrums(
        header=header,
        hourly_spectrums=hourly_spectrums,
    )


@parsec.generate
def station_spectrums_list_parser() -> List[ParsedStationSpectrums]:
    yield parsec.spaces()
    station_spectrums: List[ParsedStationSpectrums] = \
        yield parsec.many1(parsec.spaces() >> station_spectrums_parser)
    return station_spectrums
