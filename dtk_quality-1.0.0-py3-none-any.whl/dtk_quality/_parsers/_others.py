from __future__ import annotations
from typing import List
import dataclasses

import parsec

#: Double quote parser
DOUBLE_QUOTE_PARSER: parsec.Parser = parsec.string('"')
#: Double quoted name parser
QUOTED_NAME_PARSER: parsec.Parser = DOUBLE_QUOTE_PARSER >> parsec.regex(r'([A-Z0-9]+)?') << DOUBLE_QUOTE_PARSER
#: Double quoted time value parser
TIME_PARSER: parsec.Parser = DOUBLE_QUOTE_PARSER >> parsec.regex(r'[0-9]{4}?') << DOUBLE_QUOTE_PARSER
#: Double quotes unit parser
UNIT_PARSER: parsec.Parser = DOUBLE_QUOTE_PARSER >> parsec.regex(r'[A-Za-z0-9\(\)\*\/]+') << DOUBLE_QUOTE_PARSER
#: Unsigned integer parser
INT_NUMBER_PARSER: parsec.Parser = parsec.regex(r'[-+]?[0-9]+')
#: Float point number parser
FLOAT_NUMBER_PARSER: parsec.Parser = parsec.regex(r'[-+]?([0-9]+(\.[0-9]*)?|[0-9]*\.[0-9]+)([eE][-+]?[0-9]+)?')


@dataclasses.dataclass
class ParsedSensorId:
    #: Network code
    network_code: str
    #: Sensor name
    sensor_name: str
    #: Location code
    location_code: str
    #: Channel code
    channel: str

    @staticmethod
    def from_str(sensor_id: str) -> ParsedSensorId:
        """
        :raise ValueError:
        """
        splitted_sensor_id: List[str] = sensor_id.split(".")
        if len(splitted_sensor_id) != 4:
            raise ValueError("The sensor_id is not valid.")
        return ParsedSensorId(
            network_code=splitted_sensor_id[0],
            sensor_name=splitted_sensor_id[1],
            location_code=splitted_sensor_id[2],
            channel=splitted_sensor_id[3],
        )
