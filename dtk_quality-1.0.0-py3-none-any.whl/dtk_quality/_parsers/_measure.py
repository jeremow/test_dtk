from typing import List, Union
import dataclasses
import datetime

import parsec

from ._others import TIME_PARSER, FLOAT_NUMBER_PARSER
from ._header import ParsedHeader, header_parser


@dataclasses.dataclass
class ParsedHourlyMeasures:
    """
    Represents a hourly measures parsed from a XML inner text.
    """
    #: Start time  parsed from the XML inner text
    start_time: datetime.time
    #: End time  parsed from the XML inner text
    end_time: datetime.time
    #: List of values parsed from the XML inner text
    values: List[Union[int, float]]


@dataclasses.dataclass
class ParsedStationMeasures:
    """
    Represents a station measures parsed from a XML inner text.
    """
    #: Header parsed from the XML inner text
    header: ParsedHeader
    #: List of hourly measures parsed from the XML inner text
    hourly_measures: List[ParsedHourlyMeasures]


@parsec.generate
def hourly_measures_parser() -> ParsedHourlyMeasures:
    """
    :raise parsec.ParseError:
    :raise ValueError:
    """
    start_time_str: str = yield TIME_PARSER
    start_time: datetime.time = datetime.datetime.strptime(start_time_str, "%H%M").time()
    yield parsec.space()
    end_time_str: str = yield TIME_PARSER
    end_time: datetime.time = datetime.datetime.strptime(end_time_str, "%H%M").time()
    values_list_parser: parsec.Parser = parsec.many1(parsec.space() >> FLOAT_NUMBER_PARSER)
    parsed_values_str: List[str] = yield values_list_parser
    parsed_values: List[float] = list(map(float, parsed_values_str))

    return ParsedHourlyMeasures(
        start_time=start_time,
        end_time=end_time,
        values=parsed_values,
    )


@parsec.generate
def station_measures_parser() -> ParsedStationMeasures:
    header: ParsedHeader = yield header_parser
    yield parsec.space()
    hourly_measures: List[ParsedHourlyMeasures] = yield parsec.many1(parsec.space() >> hourly_measures_parser)

    return ParsedStationMeasures(
        header=header,
        hourly_measures=hourly_measures,
    )


@parsec.generate
def station_measures_list_parser() -> List[ParsedStationMeasures]:
    yield parsec.spaces()
    station_measures: List[ParsedStationMeasures] = \
        yield parsec.many1(parsec.spaces() >> station_measures_parser)
    return station_measures
