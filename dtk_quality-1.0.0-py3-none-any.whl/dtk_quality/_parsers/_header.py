import dataclasses

import parsec

from ._others import QUOTED_NAME_PARSER, INT_NUMBER_PARSER


@dataclasses.dataclass
class ParsedHeader:
    """
    Represents a header parsed from a XML inner text.
    """
    #: Sensor name parsed from the XML inner text.
    sensor_name: str
    #: Channel name parsed from the XML inner text.
    channel: str
    #: Network code parsed from the XML inner text.
    network_code: str
    #: Location code parsed from the XML inner text.
    location_code: str
    #: Number parsed
    number: int


@parsec.generate
def header_parser() -> ParsedHeader:
    """
    Parses a header string such as ``'"ARA0" "BHE" "IM" "" 400'``
    and return the header values in a ``dict``

    :raise parsec.ParseError: if the header is not valid
    """
    sensor_name: str = yield QUOTED_NAME_PARSER
    yield parsec.space()
    channel: str = yield QUOTED_NAME_PARSER
    yield parsec.space()
    network_code: str = yield QUOTED_NAME_PARSER
    yield parsec.space()
    location_code: str = yield QUOTED_NAME_PARSER
    yield parsec.space()
    number_str: str = yield INT_NUMBER_PARSER
    number: int = int(number_str)

    return ParsedHeader(
        sensor_name=sensor_name,
        channel=channel,
        network_code=network_code,
        location_code=location_code,
        number=number,
    )
