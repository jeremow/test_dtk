from typing import List, Dict, Optional, Any, TextIO
import os
import datetime
import xml.etree.ElementTree as ET
import tempfile
import subprocess
import shutil

from ._parsers import (
    station_measures_list_parser, ParsedStationMeasures,
    station_spectrums_list_parser, ParsedStationSpectrums,
)
from ._parsers._header import ParsedHeader
from ._parsers._others import ParsedSensorId
from ._measure import (
    MeasureType, MeasureData,
)
from ._spectrum import SpectrumData
from ._utils import date_range


def _convert_h5_into_xml(
    h5_file_path: str,
    xml_file_path: str,
):
    """
    Converts a HDF5 file into a XML file using the executable ``h5dump``.

    :param h5_file_path: Path of the input HDF5 file.
    :param xml_file_path: Path of the outgput XML file.
    """
    h5dump_executable: str = os.environ.get('H5DUMP_EXE', "h5dump")
    h5dump_cmd: List[str] = [
        h5dump_executable,
        "-m", "%0.41g",  # format the floating point numbers
        "--xml", h5_file_path,
    ]
    with open(xml_file_path, mode="w", encoding="utf-8") as fout:
        _process: subprocess.CompletedProcess = subprocess.run(  # pylint: disable=
            h5dump_cmd, shell=True, stdout=fout, encoding="utf-8", check=True,
        )


def _read_measures_from_h5_file(h5_file_path: str, measure_type: MeasureType) -> List[ParsedStationMeasures]:
    """
    Read measures from a NetCDF4/HDF5 quality measaure file.
    :raise ValueError:
    """
    parsed_station_measures: List[ParsedStationMeasures] = []
    xml_file: int
    xml_file_path: str
    try:
        (xml_file, xml_file_path) = tempfile.mkstemp(prefix="tmp_dtk_quality_", suffix=".xml")

        # Conversion of the HDF5 file into a temporary XML file
        _convert_h5_into_xml(h5_file_path=h5_file_path, xml_file_path=xml_file_path)

        # Parsing of the temporary XML file
        tree: ET.ElementTree = ET.parse(xml_file_path)
        root_elmt: ET.Element = tree.getroot()
        namespaces: Dict[str, str] = {
            "hdf5": "http://hdfgroup.org/HDF5/XML/schema/HDF5-File.xsd",
        }
        xml_name: str = measure_type.xml_name
        data_from_file_elmt: Optional[ET.Element] = root_elmt.find(
            f"./hdf5:RootGroup[@H5Path='/']/hdf5:Dataset[@Name='{xml_name:s}']/hdf5:Data/hdf5:DataFromFile",
            namespaces=namespaces,
        )
        if data_from_file_elmt is None:
            # Remove the temporary file
            os.close(xml_file)
            os.remove(xml_file_path)
            return []
        xml_inner_text: Optional[str] = data_from_file_elmt.text
        if xml_inner_text is None:
            raise ValueError()
        xml_inner_text = xml_inner_text.strip()  # remove leading and trailing whitespace
        parsed_station_measures = station_measures_list_parser.parse(xml_inner_text)
    except Exception as err:
        # Remove the temporary file
        os.close(xml_file)
        os.remove(xml_file_path)
        raise err from err
    # Remove the temporary file
    os.close(xml_file)
    os.remove(xml_file_path)
    return parsed_station_measures


def _read_spectrums_from_h5_file(h5_file_path: str) -> List[ParsedStationSpectrums]:
    """
    :raise ValueError:
    """
    # Value of the XML attribute ``Name``
    XML_NAME: str = "PsdStation"

    parsed_station_spectrums: List[ParsedStationSpectrums] = []
    xml_file: int
    xml_file_path: str
    try:
        (xml_file, xml_file_path) = tempfile.mkstemp(prefix="tmp_dtk_quality_", suffix=".xml")

        # Conversion of the HDF5 file into a temporary XML file
        _convert_h5_into_xml(h5_file_path=h5_file_path, xml_file_path=xml_file_path)

        # Parsing of the temporary XML file
        tree: ET.ElementTree = ET.parse(xml_file_path)
        root_elmt: ET.Element = tree.getroot()
        namespaces: Dict[str, str] = {
            "hdf5": "http://hdfgroup.org/HDF5/XML/schema/HDF5-File.xsd",
        }
        data_from_file_elmt: Optional[ET.Element] = root_elmt.find(
            f"./hdf5:RootGroup[@H5Path='/']/hdf5:Dataset[@Name='{XML_NAME:s}']/hdf5:Data/hdf5:DataFromFile",
            namespaces=namespaces,
        )
        if data_from_file_elmt is None:
            # Remove the temporary file
            os.close(xml_file)
            os.remove(xml_file_path)
            return []
        xml_inner_text: Optional[str] = data_from_file_elmt.text
        if xml_inner_text is None:
            raise ValueError()
        xml_inner_text = xml_inner_text.strip()  # remove leading and trailing whitespace
        parsed_station_spectrums = station_spectrums_list_parser.parse(xml_inner_text)
    except Exception as err:
        # Remove the temporary file
        os.close(xml_file)
        os.remove(xml_file_path)
        raise err from err
    # Remove the temporary file
    os.close(xml_file)
    os.remove(xml_file_path)
    return parsed_station_spectrums


def read_spectrums(
    spectrum_path: str,
    station_name: str, sensor_id: str,
    start_time: datetime.datetime, end_time: datetime.datetime,
) -> List[SpectrumData]:
    """
    Retrieves spectrums from DTK-Quality (Computer) NetCDF output files.

    This function uses the `h5dump` command-line tool to convert NetCDF files to easily parsable XML
    ones. Therefore, the HDF5 utilities MUST be installed on your system before calling it.

    :param spectrum_path: Path of the root directory containing DTK-Quality spectrum files
    :param station_name: A station name
    :param sensor_id: A sensor identifier in the miniSEED format (e.g., 'IM.MK01.00.SHZ')
    :param start_time: Start time of the measures to read
    :param end_time: End time of the measures to read

    :return: Structure list storing the extracted spectrum data

    :raise ValueError: If the argument ``sensor_id`` does not follow the required pattern namely ``"net.sta.loc.chan"``

    Example:

    .. code-block:: python

        import datetime

        from dtk_quality import read_spectrums

        spectrums = read_spectrums(
            spectrum_path='/path/to/spectrum/root/dir',
            station_name='AKASG',
            sensor_id='IM.AK01..BHZ',
            start_time=datetime.datetime(2019, 6, 1),
            end_time=datetime.datetime(2019, 6, 1, 1, 0, 0)
        )

    """
    parsed_sensor_id: ParsedSensorId = ParsedSensorId.from_str(sensor_id)
    spectrums: List[SpectrumData] = []
    current_date: datetime.date
    for current_date in date_range(start_time, end_time):
        first_january: datetime.date = current_date.replace(month=1, day=1)
        day_of_the_year: int = (current_date - first_january).days + 1
        data_dir_rel_path: str = os.path.join(
            f"{current_date.year:04d}",
            f"{current_date.year:04d}-{day_of_the_year:03d}",
        )
        file_name = station_name + ".nc"
        file_path: str = os.path.join(spectrum_path, data_dir_rel_path, file_name)
        if not os.path.exists(file_path):
            continue
        parsed_spectrums_list: List[ParsedStationSpectrums] = _read_spectrums_from_h5_file(h5_file_path=file_path)  # pylint: disable=line-too-long
        # Filter the parsed spectrums using the sensor id
        parsed_spectrums_list = list(filter(
            lambda x:
                x.header.network_code == parsed_sensor_id.network_code
                and x.header.sensor_name == parsed_sensor_id.sensor_name
                and x.header.location_code == parsed_sensor_id.location_code
                and x.header.channel == parsed_sensor_id.channel,
            parsed_spectrums_list,
        ))

        # Loop over the parsed spectrums
        for parsed_spectrums in parsed_spectrums_list:
            parsed_header: ParsedHeader = parsed_spectrums.header
            for hourly_spectrums in parsed_spectrums.hourly_spectrums:
                parsed_start_time: datetime.datetime = datetime.datetime.combine(current_date, hourly_spectrums.start_time)  # pylint: disable=line-too-long
                nb_frequencies: int = len(hourly_spectrums.frequencies)
                spectrums.append(SpectrumData(
                    station_name=station_name,
                    network_code=parsed_header.network_code,
                    sensor_name=parsed_header.sensor_name,
                    location_code=parsed_header.location_code,
                    channel=parsed_header.channel,
                    start_time=parsed_start_time,
                    week_day=parsed_start_time.date().weekday() + 1,
                    amp=hourly_spectrums.values,
                    freq=hourly_spectrums.frequencies,
                    unit=hourly_spectrums.unit,
                    nb_freq=nb_frequencies,
                ))

    # Filter the parsed spectrums following the start time
    spectrums = list(filter(
        lambda x: x.start_time >= start_time and x.start_time < end_time,
        spectrums,
    ))

    return spectrums


def read_measures(
    measure_path: str,
    station_name: str, sensor_id: str,
    start_time: datetime.datetime, end_time: datetime.datetime,
    measure_name: str,
) -> List[MeasureData]:
    """
    Retrieves measures from DTK-Quality (Computer) NetCDF output files.

    This function uses the `h5dump` command-line tool to convert NetCDF files to easily parsable XML
    ones. Therefore, the HDF5 utilities MUST be installed on your system before calling it.

    :param measure_path: Path of the root directory containing DTK-Quality measure files
    :param station_name: A station name
    :param sensor_id: A sensor identifier in the miniSEED format (e.g., 'IM.MK01.00.SHZ')
    :param start_time: Start time of the measures to read
    :param end_time: End time of the measures to read
    :param measure_name: Name of the measures to read, specified as one of the following values:
    'MissingData', 'SignalOffset', 'SignalRms', 'PsdRms', 'SwellPeak', 'NoiseModelComparison'

    :return: Structure list storing the extracted measure data

    :raise ValueError: If the argument ``sensor_id`` does not follow the required pattern namely ``"net.sta.loc.chan"``
    :raise ValueError: If the argument ``measure_name`` is not valid

    Example:

    .. code-block:: python

        import datetime

        from dtk_quality import read_measures

        measures = read_measures(
            measure_path='/path/to/measure/root/dir',
            station_name='AKASG',
            sensor_id='IM.AK01..BHZ',
            start_time=datetime.datetime(2019, 6, 1),
            end_time=datetime.datetime(2019, 6, 1, 1, 0, 0),
            measure_name='MissingData',
        )
    """
    parsed_sensor_id: ParsedSensorId = ParsedSensorId.from_str(sensor_id)
    measure_type = MeasureType(measure_name)
    measures: List[MeasureData] = []
    current_date: datetime.date
    for current_date in date_range(start_time, end_time):
        first_january: datetime.date = current_date.replace(month=1, day=1)
        day_of_the_year: int = (current_date - first_january).days + 1
        data_dir_rel_path: str = os.path.join(
            f"{current_date.year:04d}",
            f"{current_date.year:04d}-{day_of_the_year:03d}",
        )
        file_name = station_name + ".nc"
        file_path: str = os.path.join(measure_path, data_dir_rel_path, file_name)
        if not os.path.exists(file_path):
            continue
        parsed_measures_list: List[ParsedStationMeasures] = _read_measures_from_h5_file(
            h5_file_path=file_path,
            measure_type=measure_type,
        )

        # Loop over the parsed spectrums
        for parsed_measures in parsed_measures_list:
            parsed_header: ParsedHeader = parsed_measures.header
            for hourly_measures in parsed_measures.hourly_measures:
                parsed_start_time: datetime.datetime = datetime.datetime.combine(current_date, hourly_measures.start_time)  # pylint: disable=line-too-long
                parsed_values: List[float] = hourly_measures.values
                number_of_required_values: int
                value: float
                param: Dict[str, Any]
                if measure_type == MeasureType.SIGNAL_RMS:
                    number_of_required_values = 3
                    if len(parsed_values) != number_of_required_values:
                        raise ValueError()
                    param = {
                        "fmin": parsed_values[0],
                        "fmax": parsed_values[1],
                    }
                    value = parsed_values[2]
                elif measure_type == MeasureType.SIGNAL_OFFSET:
                    number_of_required_values = 1
                    if len(parsed_values) != number_of_required_values:
                        raise ValueError()
                    value = parsed_values[0]
                    param = {}
                elif measure_type == MeasureType.PSD_RMS:
                    number_of_required_values = 3
                    if len(parsed_values) != number_of_required_values:
                        raise ValueError()
                    param = {
                        "fmin": parsed_values[0],
                        "fmax": parsed_values[1],
                    }
                    value = parsed_values[2]
                elif measure_type == MeasureType.SWELL_PEAK:
                    number_of_required_values = 2
                    if len(parsed_values) != number_of_required_values:
                        raise ValueError()
                    param = {
                        "frequency": parsed_values[0],
                    }
                    value = parsed_values[1]
                elif measure_type == MeasureType.NOISE_MODEL_COMPARISON:
                    number_of_required_values = 4
                    if len(parsed_values) != number_of_required_values:
                        raise ValueError()
                    param = {
                        "fmin": parsed_values[0],
                        "fmax": parsed_values[1],
                    }
                    value = {
                        "below": int(parsed_values[2]),
                        "above": int(parsed_values[3]),
                    }
                elif measure_type == MeasureType.MISSING_DATA:
                    number_of_required_values = 3
                    if len(parsed_values) != number_of_required_values:
                        raise ValueError()
                    value = parsed_values[2]  # percentage
                    param = {
                        "missing_count": int(parsed_values[0]),
                        "total_size": int(parsed_values[1]),
                    }
                else:
                    raise ValueError()
                measure = MeasureData(
                    station_name=station_name,
                    network_code=parsed_header.network_code,
                    sensor_name=parsed_header.sensor_name,
                    location_code=parsed_header.location_code,
                    channel=parsed_header.channel,
                    start_time=parsed_start_time,
                    week_day=parsed_start_time.date().weekday() + 1,
                    value=value,
                    param=param,
                    measure_type=measure_type,
                )
                measures.append(measure)

    # Filter the measures using the sensor id
    measures = list(filter(
        lambda x:
            x.network_code == parsed_sensor_id.network_code
            and x.sensor_name == parsed_sensor_id.sensor_name
            and x.location_code == parsed_sensor_id.location_code
            and x.channel == parsed_sensor_id.channel,
        measures,
    ))

    # Filter the measures following the start time
    measures = list(filter(
        lambda x: x.start_time >= start_time and x.start_time < end_time,
        measures,
    ))

    # Sort the measures with the start time
    measures = sorted(measures, key=lambda x: x.start_time)

    return measures
