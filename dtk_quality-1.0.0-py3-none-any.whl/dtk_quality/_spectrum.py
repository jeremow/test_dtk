from typing import List
import dataclasses
import datetime


@dataclasses.dataclass
class SpectrumData:
    """
    This class represents one hourly sprectrum read from a sprectrum data file.
    """
    #: Station name
    station_name: str
    #: Network code
    network_code: str
    #: Sensor name
    sensor_name: str
    #: Location code
    location_code: str
    #: Channel code
    channel: str
    #: Start time of the measurements
    start_time: datetime.datetime
    #: Week day of the measurements
    week_day: int
    #: Spectral amplitudes vector
    amp: List[float]
    #: Spectral frequencies vector
    freq: List[float]
    #: Unit
    unit: str
    #: Number of frequencies
    nb_freq: int
