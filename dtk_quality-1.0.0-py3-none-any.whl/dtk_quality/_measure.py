from __future__ import annotations
import dataclasses
from typing import Dict, Union
import datetime
from enum import Enum, unique


@unique
class MeasureType(str, Enum):
    """
    This class represents all types of measure.
    """
    #: Signal RMS
    SIGNAL_RMS = "SignalRms"
    #: Signal Offset
    SIGNAL_OFFSET = "SignalOffset"
    #: PSD RMS
    PSD_RMS = "PsdRms"
    #: Sweel Peak
    SWELL_PEAK = "SwellPeak"
    #: Noise Model Comparison
    NOISE_MODEL_COMPARISON = "NoiseModelComparison"
    #: Missing Data
    MISSING_DATA = "MissingData"

    @property
    def xml_name(self) -> str:
        """
        Returns the value of each XML attribute ``hdf5:Dataset[@Name]``
        to selected the required XML tag.
        """
        if self == MeasureType.SIGNAL_RMS:
            return "SignalRmsStation"
        elif self == MeasureType.SIGNAL_OFFSET:
            return "SignalOffsetStation"
        elif self == MeasureType.PSD_RMS:
            return "PsdRmsStation"
        elif self == MeasureType.SWELL_PEAK:
            return "SwellPeakStation"
        elif self == MeasureType.NOISE_MODEL_COMPARISON:
            return "NoiseModelComparisonStation"
        elif self == MeasureType.MISSING_DATA:
            return "MissingDataStation"
        raise ValueError()


@dataclasses.dataclass
class MeasureData:  # pylint: disable=too-many-instance-attributes
    """
    This class represents one hourly measure read from a measure data file.
    """

    #: Name of the station
    station_name: str
    #: Network code
    network_code: str
    #: Sensor name
    sensor_name: str
    #: Location code
    location_code: str
    #: Channel name
    channel: str
    #: Start time of the measure
    start_time: datetime.datetime
    #: Week day
    week_day: int
    #: Values of the measure
    value: Union[int, float, Dict[str, Union[int, float]]]
    #: Parameters of the measure
    param: Dict[str, Union[int, float]]
    #: Measure type
    measure_type: MeasureType
